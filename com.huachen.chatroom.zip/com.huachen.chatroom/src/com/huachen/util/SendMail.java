package com.huachen.util;

import java.io.IOException;

import javax.servlet.Servlet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.huachen.service.UserService;
import com.huachen.service.Impl.UserServiceImpl;

@WebServlet("/SendMail")
public class SendMail extends HttpServlet implements Servlet {

	private static final long serialVersionUID = 1L;
	private static final int validtime = 1000 * 60 * 10; // 10 minutes

	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String action = request.getParameter("action");

		if (action.equals("ReSet")) {
			String token = request.getParameter("token");

			String rawtoken = "";
			rawtoken = token;

			long currTimeMillis = System.currentTimeMillis();
			long prevTimeMillis = Long.parseLong(rawtoken.split(" ")[0]);
			if (currTimeMillis - prevTimeMillis > validtime) {
				request.setAttribute("msg", "检验码已过期，请重新发送右键");
				request.getRequestDispatcher("FindPassword.jsp").forward(request, response);
				return;
			}

			request.setAttribute("token", token);
			request.getRequestDispatcher("/ReSet.jsp").forward(request, response);
			return;
		}
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String action = request.getParameter("action");

		if (action.equals("sendmail")) {
			String userName = request.getParameter("userName");
			String userMail = null;

			UserService userservice = new UserServiceImpl();
			userMail = userservice.selectMail(userName);

			String token = System.currentTimeMillis() + " " + userName;

			String genurl = "localhost:8080/com.huachen.chatroom/SendMail?action=ReSet&token=" + token;
			String mailContent = "<div>" + "<div>亲爱的聊天室用户</div>"
					+ "<div>您已经在本聊天室申请了找回密码，请点击下面链接，重新设置您的密码：</div>" + "<div><a href=\"" + genurl + "\">" + genurl
					+ "</a></div>" + "<div>此信是由聊天室系统发出，系统不接受回信，请勿直接回复。</div>" + "<div>致礼！</div>" + "</div>";
			MailUtils.sendEmail("1213018820@qq.com", "ppabylzakledhjbi", new String[] { userMail },
					"请重置您的聊天室账号的密码", mailContent, null, "text/html", "UTF8");
			request.setAttribute("msg", "短信已发送，请注意查收");
			request.getRequestDispatcher("FindPassword.jsp").forward(request, response);
			return;
		} else if (action.equals("ReSetPwd")) {
			String nextPassword = request.getParameter("nextPassword");
			String token = request.getParameter("token");

			String rawtoken = "";
			rawtoken = token;
			long currTimeMillis = System.currentTimeMillis();
			long prevTimeMillis = Long.parseLong(rawtoken.split(" ")[0]);
			if (currTimeMillis - prevTimeMillis > validtime) {
				request.getRequestDispatcher("FindPassword").forward(request, response);
				return;
			}

			UserService userservice = new UserServiceImpl();
			String userName = rawtoken.split(" ")[1];
			if(nextPassword != null) {
				if(nextPassword.length() >0 && nextPassword.length() <=16) {
					nextPassword = DigertUtils.md5(nextPassword);
					
					if (true == userservice.update(userName, nextPassword)) {
						request.setAttribute("msg", "修改密码成功");
						request.getRequestDispatcher("FindPassword.jsp").forward(request, response);
						return;
					} else {
						request.setAttribute("msg", "修改密码失败");
						request.getRequestDispatcher("ReSet.jsp").forward(request, response);
						return;
					}
				}else
				{
					request.setAttribute("msg", "修改密码的密码长度错误");
					request.getRequestDispatcher("ReSet.jsp").forward(request, response);
					return;
				}
			}else {
				request.setAttribute("msg", "密码不能为空");
				request.getRequestDispatcher("RedSet.jsp").forward(request, response);
				return;
			}
			
			

		}
	}
}