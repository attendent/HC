package com.huachen.control;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.huachen.model.User;
import com.huachen.service.ChatService;
import com.huachen.service.UserService;
import com.huachen.service.Impl.ChatServiceImpl;
import com.huachen.service.Impl.UserServiceImpl;

@WebServlet("/Invite")
public class Invite extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public Invite() {
        super();
    }

    @Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}
	
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String friendId = request.getParameter("friendId");
		String roomId = request.getParameter("roomId");
		
		ChatService chatservice = new ChatServiceImpl();
		UserService userservice = new UserServiceImpl();
		
		if(chatservice.isExistUser(Integer.parseInt(roomId),Integer.parseInt(friendId)) == false) {
			userservice.addUserRoom(Integer.parseInt(friendId), Integer.parseInt(roomId));
			
			List<User> userlist = new ArrayList<>();
			userlist = chatservice.getAllUsers(Integer.parseInt(roomId));
			request.getSession().setAttribute("userlist",userlist);
			
			request.setAttribute("msg", "邀请好友成功");
			request.getRequestDispatcher("Index.jsp").forward(request, response);
		}
		else {
			request.setAttribute("msg", "邀请好友失败");
			request.getRequestDispatcher("Index.jsp").forward(request, response);
		}
	}
}
