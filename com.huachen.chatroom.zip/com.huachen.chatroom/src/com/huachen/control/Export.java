package com.huachen.control;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.huachen.model.ChatContent;
import com.huachen.service.ChatService;
import com.huachen.service.Impl.ChatServiceImpl;
import com.huachen.util.WordUtil;

@WebServlet("/Export")
public class Export extends HttpServlet {
	private static final long serialVersionUID = 1L;
	     
    public Export() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		this.doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
        String fileName = "消息记录.doc";
        
        String roomId = request.getParameter("roomId");

		ChatService chatservice = new ChatServiceImpl();
		List<ChatContent> contents = new ArrayList<>();

		contents = chatservice.getAllContents(Integer.parseInt(roomId));
		Map<String, Object> mapvalue = new HashMap<String, Object>();
		
		List<String> record = new ArrayList<>();
		
		for (ChatContent content : contents) {
			record.add(content.getUserName() + " 于 " + content.getDate() + " 说： " + content.getContent());
		}
		mapvalue.put("contents", record);		
		
		String endCodeFileName = new String(fileName
				.getBytes("GBK"), "ISO8859-1");
		response.reset();
		response.setHeader("Content-Type",
					"application/octet-stream;charset=UTF-8");
		response.setHeader("Content-Disposition",
					"attachment;filename=" + endCodeFileName);
		response.setHeader("Connection", "close");
		
		WordUtil wUtil = new WordUtil();
		wUtil.createDoc(mapvalue, response.getOutputStream());
		
		request.getRequestDispatcher("Index.jsp").forward(request, response);
	}

}
